This is Chinese translation of `Obect-Oriented Programming with ANSI-C`
by the Fandol Team, released as pdf E-book with source code.

We use our `ebook` package for generating the book, which comes with
Chinese support by the `ctex` package or `luatexja` according what
engine you are using.

Since the fonts we used in `ooc` might not usable when you try to generate
this book yourself, it might failed on your TeX system, or the result is
somewhat different with ours. It doesn't matter.

Because we do not have enough time, this work may last for quite a long time
(actually it does last for a looooong time, thanks for your attention),
and there must be `bugs` in the translation.

If you can offer help, please connect us, we'll be glad to listen to you.


                                              LiTuX, The Fandol Team
                                                  Jan, 2014

